package com.company;

public class Person
{
    String FirstName;
    String LastName;
    City city;
    String BirthDay;
    Gender gender;

    public City getCity()
    {
        return city;
    }
    
    public String getFirstName()
    {
        return FirstName;
    }
    
    public String getLastName()
    {
        return LastName;
    }
}
