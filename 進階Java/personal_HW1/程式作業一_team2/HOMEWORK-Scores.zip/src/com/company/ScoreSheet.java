package com.company;

public class ScoreSheet
{
    int Math;
    int English;
    int Chinese;
    double Average;

    public int getMath() { return Math; }
    public int getEnglish() { return English; }
    public int getChinese() { return Chinese; }
    public double getAverage() { return Average; }
}
